import { useParams, Link } from 'react-router-dom';
import { CheckCircle, Calendar, Clock, MapPin } from 'lucide-react';
import { Navbar } from '../components/navbar';
import { Footer } from '../components/footer';
import { Button } from '../components/button';
import { events } from '../data/events';

export function Confirmation() {
  const { id } = useParams();
  const event = events.find(e => e.id === id);

  if (!event) {
    return (
      <div className="min-h-screen bg-neutral-50 flex flex-col">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center flex-1">
          <h2 className="mb-4">Event not found</h2>
          <Link to="/">
            <Button variant="primary">Back to Events</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <Navbar />
      
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 flex-1">
        {/* Success Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 rounded-full bg-success-100 flex items-center justify-center">
            <CheckCircle className="w-12 h-12 text-success-600" />
          </div>
        </div>

        {/* Success Message */}
        <div className="text-center mb-8">
          <h1 className="text-neutral-900 mb-3">You're registered!</h1>
          <p className="text-neutral-600 text-lg">
            We've sent a confirmation to your email with all the event details.
          </p>
        </div>

        {/* Event Summary Card */}
        <div className="bg-white rounded-xl border border-neutral-200 p-6 sm:p-8 mb-8 shadow-sm">
          <h3 className="text-neutral-900 mb-6">{event.name}</h3>
          
          <div className="flex flex-col gap-4">
            <div className="flex items-start gap-3">
              <Calendar className="w-5 h-5 text-maroon-700 mt-0.5 flex-shrink-0" />
              <div>
                <small className="text-neutral-500 block font-medium">Date</small>
                <p className="text-neutral-900">{event.date}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock className="w-5 h-5 text-maroon-700 mt-0.5 flex-shrink-0" />
              <div>
                <small className="text-neutral-500 block font-medium">Time</small>
                <p className="text-neutral-900">{event.time}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-maroon-700 mt-0.5 flex-shrink-0" />
              <div>
                <small className="text-neutral-500 block font-medium">Location</small>
                <p className="text-neutral-900">{event.location}</p>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-maroon-50 rounded-lg border border-maroon-100">
            <small className="text-maroon-900">
              <strong>What's next?</strong> Add this event to your calendar and we'll see you there! 
              If you have any questions, please contact {event.hostedBy}.
            </small>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Link to="/" className="flex-1">
            <Button variant="primary" size="lg" className="w-full">
              Back to Events
            </Button>
          </Link>
          <a href="#" className="flex-1">
            <Button variant="outline" size="lg" className="w-full">
              View My Registrations
            </Button>
          </a>
        </div>
      </div>

      <Footer />
    </div>
  );
}