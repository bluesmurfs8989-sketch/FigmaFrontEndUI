import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Navbar } from '../components/navbar';
import { Footer } from '../components/footer';
import { Button } from '../components/button';
import { Input, Textarea, Select } from '../components/input';
import { events } from '../data/events';

interface FormData {
  fullName: string;
  email: string;
  studentId: string;
  year: string;
  questions: string;
}

interface FormErrors {
  fullName?: string;
  email?: string;
  studentId?: string;
}

export function RegistrationForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const event = events.find(e => e.id === id);

  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    email: '',
    studentId: '',
    year: '',
    questions: ''
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!event) {
    return (
      <div className="min-h-screen bg-neutral-50 flex flex-col">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center flex-1">
          <h2 className="mb-4">Event not found</h2>
          <Link to="/">
            <Button variant="primary">Back to Events</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    } else if (!formData.email.toLowerCase().endsWith('.edu')) {
      newErrors.email = 'Please use your university email (.edu)';
    }

    if (!formData.studentId.trim()) {
      newErrors.studentId = 'Student ID is required';
    } else if (!/^\d+$/.test(formData.studentId)) {
      newErrors.studentId = 'Student ID must contain only numbers';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      navigate(`/confirmation/${event.id}`);
    }, 1000);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const yearOptions = [
    { value: '', label: 'Select your year' },
    { value: 'first-year', label: 'First-Year' },
    { value: 'sophomore', label: 'Sophomore' },
    { value: 'junior', label: 'Junior' },
    { value: 'senior', label: 'Senior' },
    { value: 'graduate', label: 'Graduate' }
  ];

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <Navbar />
      
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 flex-1">
        {/* Back Link */}
        <Link 
          to={`/event/${event.id}`}
          className="inline-flex items-center gap-2 text-maroon-700 hover:text-maroon-800 mb-6 transition-colors font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Event</span>
        </Link>

        {/* Page Title */}
        <h1 className="text-neutral-900 mb-2">Register for {event.name}</h1>
        <p className="text-neutral-600 mb-8">
          Fill out the form below to secure your spot at this event.
        </p>

        {/* Registration Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-neutral-200 p-6 sm:p-8 shadow-sm">
          <div className="flex flex-col gap-6">
            <Input
              id="fullName"
              name="fullName"
              type="text"
              label="Full Name"
              value={formData.fullName}
              onChange={handleChange}
              error={errors.fullName}
              placeholder="John Doe"
              required
            />

            <Input
              id="email"
              name="email"
              type="email"
              label="University Email"
              value={formData.email}
              onChange={handleChange}
              error={errors.email}
              placeholder="john.doe@umn.edu"
              required
            />

            <Input
              id="studentId"
              name="studentId"
              type="text"
              label="Student ID"
              value={formData.studentId}
              onChange={handleChange}
              error={errors.studentId}
              placeholder="123456789"
              required
            />

            <Select
              id="year"
              name="year"
              label="Year"
              value={formData.year}
              onChange={handleChange}
              options={yearOptions}
              required
            />

            <Textarea
              id="questions"
              name="questions"
              label="Questions or accommodations (Optional)"
              value={formData.questions}
              onChange={handleChange}
              placeholder="Let us know if you have any questions or require special accommodations..."
            />

            {/* Form Actions */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button 
                type="submit" 
                variant="primary" 
                size="lg"
                className="sm:flex-1"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Submitting...' : 'Submit Registration'}
              </Button>
              <Link 
                to={`/event/${event.id}`}
                className="sm:flex-1"
              >
                <Button 
                  type="button" 
                  variant="outline" 
                  size="lg"
                  className="w-full"
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
              </Link>
            </div>
          </div>
        </form>

        {/* Event Summary Card */}
        <div className="mt-6 bg-maroon-50 border border-maroon-200 rounded-xl p-6 shadow-sm">
          <h4 className="text-neutral-900 mb-3">Event Summary</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <small className="text-neutral-600 block font-medium">Date</small>
              <p className="text-neutral-900">{event.date}</p>
            </div>
            <div>
              <small className="text-neutral-600 block font-medium">Time</small>
              <p className="text-neutral-900">{event.time}</p>
            </div>
            <div className="sm:col-span-2">
              <small className="text-neutral-600 block font-medium">Location</small>
              <p className="text-neutral-900">{event.location}</p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}