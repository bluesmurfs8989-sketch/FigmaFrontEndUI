import { useParams, Link, useNavigate } from 'react-router-dom';
import { Calendar, Clock, MapPin, Users, ArrowLeft } from 'lucide-react';
import { Navbar } from '../components/navbar';
import { Footer } from '../components/footer';
import { Button } from '../components/button';
import { events } from '../data/events';

export function EventDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const event = events.find(e => e.id === id);

  if (!event) {
    return (
      <div className="min-h-screen bg-neutral-50 flex flex-col">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center flex-1">
          <h2 className="mb-4">Event not found</h2>
          <Link to="/">
            <Button variant="primary">Back to Events</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const spotsRemaining = event.capacity - event.registered;
  const percentageFilled = (event.registered / event.capacity) * 100;

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 flex-1">
        {/* Back Link */}
        <Link 
          to="/" 
          className="inline-flex items-center gap-2 text-maroon-700 hover:text-maroon-800 mb-6 transition-colors font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Events</span>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Event Image */}
            <div className="h-64 sm:h-96 rounded-xl overflow-hidden bg-neutral-100 mb-6 shadow-lg">
              <img 
                src={event.imageUrl} 
                alt={event.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Category Chip */}
            <div className="mb-4">
              <span className="inline-flex px-4 py-2 bg-gold-300 text-maroon-900 rounded-full font-semibold">
                {event.category}
              </span>
            </div>

            {/* Event Title */}
            <h1 className="text-neutral-900 mb-6">{event.name}</h1>

            {/* Event Description */}
            <div className="bg-white rounded-xl border border-neutral-200 p-6 sm:p-8 shadow-sm">
              <h3 className="text-neutral-900 mb-4">About this event</h3>
              <p className="text-neutral-700 leading-relaxed">
                {event.fullDescription}
              </p>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl border border-neutral-200 p-6 sticky top-24 shadow-sm">
              <h4 className="text-neutral-900 mb-6">Event Details</h4>

              <div className="flex flex-col gap-4 mb-6">
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-maroon-700 mt-0.5 flex-shrink-0" />
                  <div>
                    <small className="text-neutral-500 block font-medium">Date</small>
                    <p className="text-neutral-900">{event.date}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-maroon-700 mt-0.5 flex-shrink-0" />
                  <div>
                    <small className="text-neutral-500 block font-medium">Time</small>
                    <p className="text-neutral-900">{event.time}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-maroon-700 mt-0.5 flex-shrink-0" />
                  <div>
                    <small className="text-neutral-500 block font-medium">Location</small>
                    <p className="text-neutral-900">{event.location}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Users className="w-5 h-5 text-maroon-700 mt-0.5 flex-shrink-0" />
                  <div>
                    <small className="text-neutral-500 block font-medium">Capacity</small>
                    <p className="text-neutral-900">
                      {event.registered} / {event.capacity} registered
                    </p>
                  </div>
                </div>
              </div>

              {/* Capacity Progress Bar */}
              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <small className="text-neutral-600 font-medium">Availability</small>
                  <small className={spotsRemaining <= 10 ? 'text-error-600 font-semibold' : 'text-success-600 font-semibold'}>
                    {spotsRemaining} spots left
                  </small>
                </div>
                <div className="w-full h-2 bg-neutral-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all ${
                      percentageFilled >= 90 ? 'bg-error-500' : 
                      percentageFilled >= 70 ? 'bg-gold-400' : 
                      'bg-success-500'
                    }`}
                    style={{ width: `${percentageFilled}%` }}
                  />
                </div>
              </div>

              {/* Hosted By */}
              <div className="mb-6 p-4 bg-maroon-50 rounded-lg border border-maroon-100">
                <small className="text-neutral-600 block mb-1 font-medium">Hosted by</small>
                <p className="text-maroon-900 font-medium">{event.hostedBy}</p>
              </div>

              {/* Register Button */}
              <Button 
                variant="primary" 
                size="lg"
                className="w-full"
                onClick={() => navigate(`/event/${event.id}/register`)}
                disabled={spotsRemaining === 0}
              >
                {spotsRemaining === 0 ? 'Event Full' : 'Register for Event'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}