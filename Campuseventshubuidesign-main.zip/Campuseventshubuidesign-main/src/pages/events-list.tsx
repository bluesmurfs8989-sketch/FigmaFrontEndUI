import { useState } from 'react';
import { Navbar } from '../components/navbar';
import { EventCard } from '../components/event-card';
import { EventFilters } from '../components/event-filters';
import { Footer } from '../components/footer';
import { Button } from '../components/button';
import { events } from '../data/events';

export function EventsList() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedDate, setSelectedDate] = useState('');

  // Filter events based on search and filters
  const filteredEvents = events.filter(event => {
    const matchesSearch = event.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.shortDescription.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || event.category === selectedCategory;
    // Date filter would require more complex logic - simplified for demo
    const matchesDate = true;
    
    return matchesSearch && matchesCategory && matchesDate;
  });

  const scrollToEvents = () => {
    document.getElementById('events-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-maroon-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <div className="max-w-3xl">
            <h1 className="text-white mb-6">
              Find and register for campus events in seconds
            </h1>
            <p className="text-maroon-100 mb-8 max-w-2xl text-lg leading-relaxed">
              Discover exciting opportunities to learn, connect, and grow. From academic workshops to social gatherings, there's something for everyone at the University of Minnesota.
            </p>
            <Button 
              variant="secondary" 
              size="lg"
              onClick={scrollToEvents}
            >
              Browse Events
            </Button>
          </div>
        </div>
      </section>

      {/* Events Section */}
      <section id="events-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-1">
        {/* Filters */}
        <div className="mb-8">
          <EventFilters
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
          />
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-neutral-700 font-medium">
            Showing {filteredEvents.length} {filteredEvents.length === 1 ? 'event' : 'events'}
          </p>
        </div>

        {/* Events Grid */}
        {filteredEvents.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map(event => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-xl border border-neutral-200">
            <p className="text-neutral-600 mb-2">No events found</p>
            <small className="text-neutral-500">
              Try adjusting your search or filters
            </small>
          </div>
        )}
      </section>

      <Footer />
    </div>
  );
}