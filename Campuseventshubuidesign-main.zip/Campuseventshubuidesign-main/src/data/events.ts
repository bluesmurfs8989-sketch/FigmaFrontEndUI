export interface Event {
  id: string;
  name: string;
  shortDescription: string;
  fullDescription: string;
  date: string;
  time: string;
  location: string;
  category: 'Academic' | 'Social' | 'Career' | 'Sports' | 'Arts';
  capacity: number;
  registered: number;
  hostedBy: string;
  imageUrl: string;
}

export const events: Event[] = [
  {
    id: '1',
    name: 'AI & Machine Learning Workshop',
    shortDescription: 'Learn the fundamentals of AI and build your first machine learning model.',
    fullDescription: 'Join us for an immersive workshop where you\'ll dive into the exciting world of artificial intelligence and machine learning. This hands-on session will cover the basics of ML algorithms, practical applications, and you\'ll build your very first predictive model. Perfect for beginners and those looking to expand their tech skills. Laptops required.',
    date: 'December 15, 2025',
    time: '2:00 PM - 5:00 PM',
    location: 'Engineering Building, Room 301',
    category: 'Academic',
    capacity: 50,
    registered: 32,
    hostedBy: 'Computer Science Department',
    imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80'
  },
  {
    id: '2',
    name: 'Winter Formal Dance',
    shortDescription: 'Annual winter formal with live music, dancing, and refreshments.',
    fullDescription: 'Get ready for the most anticipated social event of the semester! Our Winter Formal features live music from local bands, a professional DJ, dancing, photo booth, and complimentary refreshments. Dress code is semi-formal to formal attire. Tickets include entry for you and one guest. Don\'t miss this magical evening!',
    date: 'December 20, 2025',
    time: '7:00 PM - 11:00 PM',
    location: 'Student Union Grand Ballroom',
    category: 'Social',
    capacity: 200,
    registered: 156,
    hostedBy: 'Student Activities Board',
    imageUrl: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=800&q=80'
  },
  {
    id: '3',
    name: 'Career Fair 2025',
    shortDescription: 'Meet with top employers and explore internship and full-time opportunities.',
    fullDescription: 'Connect with over 80 companies actively recruiting students for internships and full-time positions. Bring multiple copies of your resume, dress professionally, and be prepared to make meaningful connections. Companies from tech, finance, healthcare, and more will be present. Free professional headshots available from 9-11 AM.',
    date: 'January 10, 2025',
    time: '10:00 AM - 4:00 PM',
    location: 'Athletics Center, Main Arena',
    category: 'Career',
    capacity: 500,
    registered: 287,
    hostedBy: 'Career Services Office',
    imageUrl: 'https://images.unsplash.com/photo-1511578314322-379afb476865?w=800&q=80'
  },
  {
    id: '4',
    name: 'Research Symposium: Climate Science',
    shortDescription: 'Student and faculty research presentations on climate change and sustainability.',
    fullDescription: 'Our annual Climate Science Research Symposium showcases groundbreaking work from students and faculty on climate change, environmental sustainability, and green technology. The event includes poster sessions, oral presentations, and a keynote address from Dr. Sarah Chen, renowned climate scientist. Open to all students interested in environmental issues.',
    date: 'December 18, 2025',
    time: '1:00 PM - 6:00 PM',
    location: 'Science Center Auditorium',
    category: 'Academic',
    capacity: 150,
    registered: 89,
    hostedBy: 'Environmental Studies Department',
    imageUrl: 'https://images.unsplash.com/photo-1758685848084-fc51214f3cd0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2llbnRpZmljJTIwcmVzZWFyY2glMjBwcmVzZW50YXRpb258ZW58MXx8fHwxNzY1MTQ3Njg4fDA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  {
    id: '5',
    name: 'Open Mic Night',
    shortDescription: 'Showcase your talent! Music, poetry, comedy - all performers welcome.',
    fullDescription: 'Express yourself at our monthly Open Mic Night! Whether you sing, play an instrument, perform spoken word poetry, do stand-up comedy, or have any other talent to share, this is your stage. Sign-ups begin at 6:30 PM. Performers get one free beverage. Supportive audience guaranteed!',
    date: 'December 12, 2025',
    time: '7:00 PM - 10:00 PM',
    location: 'Campus Coffee House',
    category: 'Arts',
    capacity: 75,
    registered: 43,
    hostedBy: 'Arts & Culture Club',
    imageUrl: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&q=80'
  },
  {
    id: '6',
    name: 'Startup Pitch Competition',
    shortDescription: 'Watch student entrepreneurs pitch their startups for a $10,000 prize.',
    fullDescription: 'Ten student teams will present their startup ideas to a panel of venture capitalists and successful entrepreneurs. The winning team receives $10,000 in seed funding plus mentorship. Even if you\'re not competing, this is an incredible opportunity to learn about entrepreneurship, network with investors, and get inspired by innovative ideas from your peers.',
    date: 'January 8, 2025',
    time: '5:00 PM - 8:30 PM',
    location: 'Business School Amphitheater',
    category: 'Career',
    capacity: 300,
    registered: 178,
    hostedBy: 'Entrepreneurship Center',
    imageUrl: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?w=800&q=80'
  },
  {
    id: '7',
    name: 'Intramural Basketball Tournament',
    shortDescription: 'Form a team and compete in our 3v3 basketball tournament.',
    fullDescription: 'Calling all hoopers! Register your 3-person team for our exciting basketball tournament. Games will be played throughout the day with championship finals in the evening. Prizes for 1st, 2nd, and 3rd place teams. All skill levels welcome - this is about fun, fitness, and school spirit!',
    date: 'December 14, 2025',
    time: '9:00 AM - 6:00 PM',
    location: 'Recreation Center Courts',
    category: 'Sports',
    capacity: 120,
    registered: 96,
    hostedBy: 'Campus Recreation',
    imageUrl: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=800&q=80'
  },
  {
    id: '8',
    name: 'International Food Festival',
    shortDescription: 'Taste dishes from around the world prepared by international student clubs.',
    fullDescription: 'Experience a culinary journey around the globe! Student organizations representing over 20 countries will prepare and serve traditional dishes from their cultures. Enjoy authentic food, learn about different traditions, watch cultural performances, and celebrate the diversity of our campus community. All proceeds support international student scholarships.',
    date: 'December 16, 2025',
    time: '11:00 AM - 3:00 PM',
    location: 'University Green (Rain location: Student Union)',
    category: 'Social',
    capacity: 400,
    registered: 312,
    hostedBy: 'International Student Association',
    imageUrl: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&q=80'
  }
];