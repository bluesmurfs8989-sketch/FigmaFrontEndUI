import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { EventsList } from './pages/events-list';
import { EventDetail } from './pages/event-detail';
import { RegistrationForm } from './pages/registration-form';
import { Confirmation } from './pages/confirmation';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<EventsList />} />
        <Route path="/event/:id" element={<EventDetail />} />
        <Route path="/event/:id/register" element={<RegistrationForm />} />
        <Route path="/confirmation/:id" element={<Confirmation />} />
      </Routes>
    </Router>
  );
}
