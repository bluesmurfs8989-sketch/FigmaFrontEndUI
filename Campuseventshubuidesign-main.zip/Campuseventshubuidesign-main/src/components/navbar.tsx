import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Navbar() {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <nav className="bg-maroon-700 border-b border-maroon-800 sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-white text-lg">Campus Events Hub</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <Link 
              to="/" 
              className={`transition-colors ${
                isActive('/') 
                  ? 'text-gold-300' 
                  : 'text-white hover:text-gold-300'
              }`}
            >
              Home
            </Link>
            <a 
              href="#" 
              className="text-white hover:text-gold-300 transition-colors"
            >
              My Registrations
            </a>
            <a 
              href="#" 
              className="text-white hover:text-gold-300 transition-colors"
            >
              About
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-maroon-800 transition-colors"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-white" />
            ) : (
              <Menu className="w-6 h-6 text-white" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-maroon-800">
            <div className="flex flex-col gap-4">
              <Link 
                to="/" 
                className={`px-4 py-2 rounded-lg transition-colors ${
                  isActive('/') 
                    ? 'bg-maroon-800 text-gold-300' 
                    : 'text-white hover:bg-maroon-800'
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Home
              </Link>
              <a 
                href="#" 
                className="px-4 py-2 text-white hover:bg-maroon-800 rounded-lg transition-colors"
              >
                My Registrations
              </a>
              <a 
                href="#" 
                className="px-4 py-2 text-white hover:bg-maroon-800 rounded-lg transition-colors"
              >
                About
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}