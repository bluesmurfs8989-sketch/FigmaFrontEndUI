import { Link } from 'react-router-dom';
import { Calendar, Clock, MapPin } from 'lucide-react';
import { Event } from '../data/events';
import { Button } from './button';

interface EventCardProps {
  event: Event;
}

export function EventCard({ event }: EventCardProps) {
  const spotsRemaining = event.capacity - event.registered;
  const isAlmostFull = spotsRemaining <= 10 && spotsRemaining > 0;
  
  return (
    <div className="bg-white rounded-xl border border-neutral-200 overflow-hidden hover:shadow-xl transition-all hover:border-maroon-700 flex flex-col h-full">
      {/* Event Image */}
      <div className="h-48 overflow-hidden bg-neutral-100">
        <img 
          src={event.imageUrl} 
          alt={event.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      
      {/* Card Content */}
      <div className="p-6 flex flex-col gap-4 flex-1">
        {/* Category Chip */}
        <div className="flex items-center justify-between">
          <span className="inline-flex px-3 py-1 bg-gold-300 text-maroon-900 rounded-full caption font-semibold">
            {event.category}
          </span>
          {isAlmostFull && (
            <span className="caption text-error-600 font-medium">
              Only {spotsRemaining} spots left!
            </span>
          )}
        </div>
        
        {/* Event Name */}
        <h3 className="text-neutral-900 line-clamp-2">{event.name}</h3>
        
        {/* Short Description */}
        <p className="text-neutral-600 line-clamp-2 flex-1">{event.shortDescription}</p>
        
        {/* Event Metadata */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 text-neutral-600">
            <Calendar className="w-4 h-4 text-maroon-700" />
            <small>{event.date}</small>
          </div>
          <div className="flex items-center gap-2 text-neutral-600">
            <Clock className="w-4 h-4 text-maroon-700" />
            <small>{event.time}</small>
          </div>
          <div className="flex items-center gap-2 text-neutral-600">
            <MapPin className="w-4 h-4 text-maroon-700" />
            <small className="line-clamp-1">{event.location}</small>
          </div>
        </div>
        
        {/* View Details Button */}
        <Link to={`/event/${event.id}`} className="mt-2">
          <Button variant="primary" className="w-full">
            View Details
          </Button>
        </Link>
      </div>
    </div>
  );
}