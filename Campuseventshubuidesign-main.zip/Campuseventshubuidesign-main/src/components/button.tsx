import { ButtonHTMLAttributes, ReactNode } from 'react';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  children: ReactNode;
}

export function Button({ 
  variant = 'primary', 
  size = 'md', 
  children, 
  className = '',
  ...props 
}: ButtonProps) {
  const baseStyles = 'inline-flex items-center justify-center rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-maroon-700 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed font-medium';
  
  const variants = {
    primary: 'bg-maroon-700 text-white hover:bg-maroon-800 active:bg-maroon-900 shadow-sm hover:shadow-md',
    secondary: 'bg-gold-300 text-maroon-900 hover:bg-gold-400 active:bg-gold-500 shadow-sm hover:shadow-md',
    outline: 'border-2 border-maroon-700 text-maroon-700 hover:bg-maroon-50 active:bg-maroon-100'
  };
  
  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3',
    lg: 'px-8 py-4 text-lg'
  };
  
  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}