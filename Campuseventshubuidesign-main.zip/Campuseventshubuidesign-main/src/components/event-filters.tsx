import { Search, ChevronDown } from 'lucide-react';

interface EventFiltersProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  selectedDate: string;
  setSelectedDate: (date: string) => void;
}

export function EventFilters({
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  selectedDate,
  setSelectedDate
}: EventFiltersProps) {
  return (
    <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-sm">
      <div className="flex flex-col md:flex-row gap-4">
        {/* Search Box */}
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
          <input
            type="text"
            placeholder="Search events"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-maroon-700 focus:border-transparent hover:border-neutral-400 transition-colors"
          />
        </div>
        
        {/* Category Filter - Pill Style */}
        <div className="relative">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="pl-4 pr-10 py-3 border-2 border-maroon-700 text-maroon-700 rounded-full focus:outline-none focus:ring-2 focus:ring-maroon-700 focus:border-transparent hover:bg-maroon-50 transition-colors bg-white cursor-pointer appearance-none md:w-48 font-medium"
          >
            <option value="">All Categories</option>
            <option value="Academic">Academic</option>
            <option value="Social">Social</option>
            <option value="Career">Career</option>
            <option value="Sports">Sports</option>
            <option value="Arts">Arts</option>
          </select>
          <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-maroon-700 pointer-events-none" />
        </div>
        
        {/* Date Filter - Pill Style */}
        <div className="relative">
          <select
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="pl-4 pr-10 py-3 border-2 border-maroon-700 text-maroon-700 rounded-full focus:outline-none focus:ring-2 focus:ring-maroon-700 focus:border-transparent hover:bg-maroon-50 transition-colors bg-white cursor-pointer appearance-none md:w-48 font-medium"
          >
            <option value="">All Dates</option>
            <option value="this-week">This Week</option>
            <option value="this-month">This Month</option>
            <option value="next-month">Next Month</option>
          </select>
          <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-maroon-700 pointer-events-none" />
        </div>
      </div>
    </div>
  );
}