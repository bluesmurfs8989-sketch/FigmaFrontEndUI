export function Footer() {
  return (
    <footer className="bg-neutral-100 border-t border-neutral-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center text-neutral-600">
          <p>Campus Events Hub · Demo Project · University of Minnesota</p>
          <small className="text-neutral-500 block mt-2">
            © 2025 All rights reserved
          </small>
        </div>
      </div>
    </footer>
  );
}
