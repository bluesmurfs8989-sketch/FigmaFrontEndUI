import { InputHTMLAttributes, TextareaHTMLAttributes, SelectHTMLAttributes, forwardRef } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, className = '', ...props }, ref) => {
    return (
      <div className="flex flex-col gap-2">
        <label htmlFor={props.id} className="text-neutral-900 font-medium">
          {label}
        </label>
        <input
          ref={ref}
          className={`px-4 py-3 border rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-maroon-700 focus:border-transparent ${
            error 
              ? 'border-error-500 focus:ring-error-500' 
              : 'border-neutral-300 hover:border-neutral-400'
          } ${className}`}
          {...props}
        />
        {error && (
          <span className="text-error-600 caption font-medium">{error}</span>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  error?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, error, className = '', ...props }, ref) => {
    return (
      <div className="flex flex-col gap-2">
        <label htmlFor={props.id} className="text-neutral-900 font-medium">
          {label}
        </label>
        <textarea
          ref={ref}
          className={`px-4 py-3 border rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-maroon-700 focus:border-transparent resize-none ${
            error 
              ? 'border-error-500 focus:ring-error-500' 
              : 'border-neutral-300 hover:border-neutral-400'
          } ${className}`}
          rows={4}
          {...props}
        />
        {error && (
          <span className="text-error-600 caption font-medium">{error}</span>
        )}
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  error?: string;
  options: { value: string; label: string }[];
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, error, options, className = '', ...props }, ref) => {
    return (
      <div className="flex flex-col gap-2">
        <label htmlFor={props.id} className="text-neutral-900 font-medium">
          {label}
        </label>
        <select
          ref={ref}
          className={`px-4 py-3 border rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-maroon-700 focus:border-transparent appearance-none bg-white cursor-pointer ${
            error 
              ? 'border-error-500 focus:ring-error-500' 
              : 'border-neutral-300 hover:border-neutral-400'
          } ${className}`}
          {...props}
        >
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        {error && (
          <span className="text-error-600 caption font-medium">{error}</span>
        )}
      </div>
    );
  }
);

Select.displayName = 'Select';